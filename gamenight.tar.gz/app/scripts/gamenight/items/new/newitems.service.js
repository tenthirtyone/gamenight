(function() {
	'use strict';
	
	angular.module('gamenight.items.new')
	.service('NewItemsService', NewItemsService);
	
	NewItemsService.$inject = ['moduleHelper']
	
	function NewItemsService(moduleHelper) {



	}
	
}());
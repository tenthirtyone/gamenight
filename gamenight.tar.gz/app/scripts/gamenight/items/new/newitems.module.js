(function() {
	'use strict';
	
	angular.module('gamenight.items.new', [
	'gamenight.items.new.item',
	'gamenight.items.new.table'
	]);
}());
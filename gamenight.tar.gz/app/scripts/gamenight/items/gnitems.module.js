(function() {
	'use strict';
	
	angular.module('gamenight.items', [
		'gamenight.items.item',
		'gamenight.items.list',
		'gamenight.items.table'
	]);
}());
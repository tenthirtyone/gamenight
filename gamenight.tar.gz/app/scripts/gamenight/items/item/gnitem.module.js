(function() {
	'use strict';
	
	angular.module('gamenight.items.item', []);
}());
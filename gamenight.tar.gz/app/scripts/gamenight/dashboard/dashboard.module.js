(function() {
	'use strict';
	
	angular.module('gamenight.dashboard', []);
}());
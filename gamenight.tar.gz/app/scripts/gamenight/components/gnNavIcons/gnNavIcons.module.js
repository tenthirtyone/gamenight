(function() {
  'use strict';
  
  angular.module('components.gnnavicon', []);
}());
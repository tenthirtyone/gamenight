(function() {
  'use strict';
  
  angular.module('components.gnnotificationlist', []);
}());
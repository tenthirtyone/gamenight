(function() {
  'use strict';
  
  angular.module('components.gnlogin', []);
}());
(function() {
  'use strict';
  
  angular.module('components', [
    'components.gnnavicon',
    'components.gndashicon',
    'components.gndashtrackable',
    'components.gnnotificationlist',
    'components.gnchanneltitle',
    'components.gnchannelbuttons',
    'components.gnlogin',
    'components.gndisplaybox'
  ]);
  
}());
(function() {
	'use strict';
	
	angular.module('gamenight.spells', []);
}());
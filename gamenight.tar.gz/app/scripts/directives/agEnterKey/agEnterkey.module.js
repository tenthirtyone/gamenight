(function() {
	'use strict';
	
	angular.module('agEnterkey', []);
								 
}());
(function() {
	'use strict';
	
	angular.module('agUploadarea', [
		'ngFileUpload'
	]);
								 
}());
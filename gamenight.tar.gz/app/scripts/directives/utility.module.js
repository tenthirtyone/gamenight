(function() {
	'use strict';
	
	angular.module('utility', [
		'agEnterkey',
		'agUploadarea'
		]);
}());
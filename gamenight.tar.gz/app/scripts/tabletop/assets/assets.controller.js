(function() {
	'use strict';
	
	angular.module('tabletop.assets')
	.controller('AssetsController', AssetsController);
	
	function AssetsController() {
		console.log('Assets Loaded');
	}
}());
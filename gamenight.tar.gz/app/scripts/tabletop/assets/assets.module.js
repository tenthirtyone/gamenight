(function(){
	'use strict';
	
	angular.module('tabletop.assets', []);
}());
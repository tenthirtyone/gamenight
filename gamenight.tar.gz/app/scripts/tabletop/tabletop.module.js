(function() {
	'use strict';
	
	angular.module('tabletop', [
		'tabletop.assets',
		'tabletop.boards',
		'tabletop.characters',
		'tabletop.games',
		'tabletop.items',
		'tabletop.spells'
	]);
}());
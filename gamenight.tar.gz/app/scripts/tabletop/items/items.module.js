(function(){
	'use strict';
	
	angular.module('tabletop.items', []);
}());
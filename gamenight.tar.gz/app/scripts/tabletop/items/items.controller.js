(function() {
	'use strict';
	
	angular.module('tabletop.items')
	.controller('ItemsController', ItemsController);
	
	function ItemsController() {
		console.log('Items Loaded');	
	}
}());
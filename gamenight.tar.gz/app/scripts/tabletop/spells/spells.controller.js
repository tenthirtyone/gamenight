(function() {
	'use strict';
	
	angular.module('tabletop.spells')
	.controller('SpellsController', SpellsController);
	
	function SpellsController() {
		
	}
}());
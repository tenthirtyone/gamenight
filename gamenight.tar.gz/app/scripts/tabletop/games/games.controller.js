(function() {
	'use strict';
	
	angular.module('tabletop.games')
	.controller('GamesController', GamesController);
	
	function GamesController() {
		console.log('Games Loaded');
	}
}());